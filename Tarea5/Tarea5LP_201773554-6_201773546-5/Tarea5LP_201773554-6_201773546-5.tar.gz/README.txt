Nombre                   Rol
Gonzalo Cruz Masferrer   201773554-6
Esteban Carrasco Galdame 201773546-5

