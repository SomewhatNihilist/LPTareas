Integrantes:
	Gonzalo Cruz Masferrer ROL: 201773554-6
	Esteban Carrasco Galdame: 201773546-5

Cambiar variable archivo_codigo para elegir variable a leer


Logramos hacer la detección de errores del lenguaje, y decir cual linea es correcta sintaxticamente, lamentablemente no pudimos implementar el colorizador, para que verifique que la deteccion de errores funciona, imprima al final del codigo la lista Token, que contiene los tokens por cada linea, indicando si esa linea es correcta o no
