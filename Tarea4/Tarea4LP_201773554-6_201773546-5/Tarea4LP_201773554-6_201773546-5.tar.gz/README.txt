Nombre                   Rol
Gonzalo Cruz Masferrer   201773554-6
Esteban Carrasco Galdame 201773546-5

Asumpsion
Los inputs son correctos de acuerdo a lo descrito en el enunciado
(No hay que hacer checheo de errores)
