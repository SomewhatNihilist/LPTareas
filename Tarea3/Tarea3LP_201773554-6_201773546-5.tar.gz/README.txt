Nombre                   Rol
Gonzalo Cruz Masferrer   201773554-6
Esteban Carrasco Galdame 201773546-5

Compilacion: En un terminal dentro de la carpeta, escribir
	ant

Ejecucion: En el mismo terminal anteriormente mencionado
	cd bin
	java juego/Juego


Asumpsion
RESISTENCIA no tiene un maximo
(La descripcion no especifica que se cure hasta un maximo de vida, por
 lo que los enanos pueden obtener ilimitada vida mas alla de su valor inicial).
