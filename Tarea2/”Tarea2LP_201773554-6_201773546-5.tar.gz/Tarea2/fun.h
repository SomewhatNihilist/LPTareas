
int fun(void* nodo);
